<?php
//date_default_timezone_set('America/Argentina/Buenos_Aires');
/**
 * Doli Chat
 */

// if (! defined('NOREQUIREUSER'))    define('NOREQUIREUSER', '1');    // Not disabled cause need to load personalized language
// if (! defined('NOREQUIREDB'))        define('NOREQUIREDB', '1');        // Not disabled cause need to load personalized language
// if (! defined('NOREQUIRESOC'))        define('NOREQUIRESOC', '1');
// if (! defined('NOREQUIRETRAN'))        define('NOREQUIRETRAN', '1');


// Load Dolibarr environment
$res=0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (! $res && ! empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res=@include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp=empty($_SERVER['SCRIPT_FILENAME'])?'':$_SERVER['SCRIPT_FILENAME'];$tmp2=realpath(__FILE__); $i=strlen($tmp)-1; $j=strlen($tmp2)-1;
while($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i]==$tmp2[$j]) { $i--; $j--; }
if (! $res && $i > 0 && file_exists(substr($tmp, 0, ($i+1))."/main.inc.php")) $res=@include substr($tmp, 0, ($i+1))."/main.inc.php";
if (! $res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i+1)))."/main.inc.php")) $res=@include dirname(substr($tmp, 0, ($i+1)))."/main.inc.php";
// Try main.inc.php using relative path
if (! $res && file_exists("../main.inc.php")) $res=@include "../main.inc.php";
if (! $res && file_exists("../../main.inc.php")) $res=@include "../../main.inc.php";
if (! $res && file_exists("../../../main.inc.php")) $res=@include "../../../main.inc.php";
if (! $res) die("Include of main fails");

// Load translation files required by the page
$langs->loadLangs(array("dolichat@dolichat"));

$action = GETPOST('action', 'aZ09');
$mensaje = GETPOST('mensaje', 'alpha');

// Security check
if (! $user->rights->dolichat->dolichat->read) {
 	accessforbidden();
}

/*
 * Actions
 */
if($action == 'sendmessage' && !empty($mensaje) ){
  $fp = fopen("./log.html", 'a');
  fwrite($fp, "<div class='msgln'><span class='chat-time'>".date("g:i A")."</span> <b style='color:".trim($conf->global->DOLICHAT_SETUP_TEXT)." !important;'>".$user->firstname.' '.$user->lastname."</b><br/>".stripslashes(htmlspecialchars(ucfirst($mensaje)))."<br></div>");
  fclose($fp);
  echo json_encode(true);
  exit;
}

 // Title
$title = 'Doli Chat - Dolibarr '.DOL_VERSION;
if (!empty($conf->global->MAIN_APPLICATION_TITLE)) {
    $title = 'Doli Chat - '.$conf->global->MAIN_APPLICATION_TITLE;
}
$head='<meta name="apple-mobile-web-app-title" content="TakePOS"/>
<meta charset=UTF-8>
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<link rel="stylesheet" href="css/style.css">
';
top_htmlhead($head, $title);
/*
 * View
 */
?>
<script type="text/javascript">

$(document).ready(function(){
  
  var oldscrollHeight = $("#chatbox")[0].scrollHeight - 20;
  
  function loadHtmllog(){
    var request = $.ajax({
      url: "./log.html",
      cache: false,
    });
    request.done(function( html ) {
      $( "#chatbox" ).html( html );
 			//Auto-scroll
			var newscrollHeight = $("#chatbox")[0].scrollHeight - 20; 
			if(newscrollHeight > oldscrollHeight){
				$("#chatbox").animate({ scrollTop: newscrollHeight }, 'normal'); 
			}				
    });
    
    request.fail(function( jqXHR, textStatus ) {
      alert( "Request failed: " + textStatus );
    });
  }
  
  parent.$("#buttonDropdown").hover(function(){
    parent.$(".dropdown-content").fadeIn(1000);
    loadHtmllog();
  });
  
  $( "#usermsg" ).focus(function(){
    setTimeout(function(){
      loadHtmllog();
    },1000);
  });
  
  parent.$("#buttonDropdown").click(function(){
    setTimeout(function() {
      parent.$(".dropdown-content").fadeOut(1000);
    },1000);
  });
  
  parent.$('body').on('click', ":not(.dropdown-content)", function(e){
    setTimeout(function() {
      parent.$(".dropdown-content").fadeOut(1000);
    },1000);
    e.stopPropagation();
  });
  
  $("form").on("submit", function(e) {
    //var dataString = $(this).serialize();
    var clientmsg = $("#usermsg").val();
   	$.ajax({
  		type: "POST",
  		url: "<?php echo DOL_URL_ROOT.'/custom/dolichat/windows_chat.php'; ?>",
  		data: { action: "sendmessage", mensaje:clientmsg ,token: '<?php echo newToken(); ?>' }
  	}).done(function( resp ) {
  	  if(resp){
       $( "#usermsg" ).val("");
       $( "#usermsg" ).focus();
  	  }
  	})
    e.preventDefault();
	});
  
});

</script>
<style>
* {
	margin: 0;
	padding: 0;
	line-height: 1;
}

</style>
</head>
<body style="overflow: hidden; padding-top: 5px;">
<div class="container">
<div class="columns">
<div class="column col-xs-12">
  <div class="panel">
    <div class="panel-header text-center">
      <div class="panel-title mt-10"><?php echo $langs->trans("MessagePanel")." ".$user->firstname." ".$user->lastname ?></div>
    </div>
    <div class="panel-body">
      <?php
      print '<div id="chatbox">';
      if(file_exists("log.html") && filesize("log.html") > 0){
      	$handle = fopen("./log.html", "r");
      	$contents = fread($handle, filesize("./log.html"));
      	fclose($handle);
      	echo $contents;
      }
      print '</div>';
      ?>
    </div>
    <div class="panel-footer">
    <form name="message" action="">
      <div class="input-group">
        <input class="form-input" name="usermsg" type="text" id="usermsg" placeholder="Envia un mensaje.." required>
        <button type="submit"  id="submitmsg" class="btn btn-primary input-group-btn"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
      </div>
    </form>
    </div>
</div>
</body>
</html>


